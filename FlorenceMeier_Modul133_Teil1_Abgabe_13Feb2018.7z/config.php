<?php
return [
    'database' => [
        'host' => '172.29.4.61',
        'name' => 'infw2017_2a_151_web15',
        'user' => 'db_000252',
        'pass' => 'DCudxctxwu2S'
    ],
    'other-stuff' => ...
];
?>